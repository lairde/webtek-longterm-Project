To view the webpage for prelims you must do the Following:

1. Unzip the file that was downloaded and place it on a specified folder or in desktop.
2. After unzipping the file go to "webteklec folder" .
3. Open it.
4. After opening the "webteklec folder" click on index.html. 